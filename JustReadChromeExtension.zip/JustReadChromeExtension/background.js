chrome.action.onClicked.addListener(async (tab) => {
  if (!tab.url) return;

  const target = encodeURIComponent(tab.url);
  const importUrl = `justread://import?url=${target}`;

  await chrome.tabs.create({ url: importUrl });
});
